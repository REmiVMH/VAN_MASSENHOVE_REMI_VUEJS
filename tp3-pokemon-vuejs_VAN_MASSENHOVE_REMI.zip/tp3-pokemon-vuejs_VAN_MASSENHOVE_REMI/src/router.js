import Vue from 'vue';
import VueRouter from 'vue-router';
import DetailsPokemon from '@/components/DetailsPokemon.vue';

Vue.use(VueRouter);

const routes = [
  {
    path: '/pokemon/:id',
    name: 'DetailsPokemon',
    component: DetailsPokemon
  }
];

const router = new VueRouter({
  routes
});

export default router;
