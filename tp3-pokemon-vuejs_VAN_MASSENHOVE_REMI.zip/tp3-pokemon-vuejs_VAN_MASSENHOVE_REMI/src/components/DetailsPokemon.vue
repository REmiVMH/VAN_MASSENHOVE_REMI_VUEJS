<template>
  <div class="details-pokemon">
    <h2>{{ pokemon.name }}</h2>
    <img :src="pokemon.image" :alt="pokemon.name" />
    <div>
      <p><strong>Type:</strong> {{ pokemon.type }}</p>
      <p><strong>Base Experience:</strong> {{ pokemon.baseExperience }}</p>
      <p><strong>Height:</strong> {{ pokemon.height }}</p>
      <p><strong>Weight:</strong> {{ pokemon.weight }}</p>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'DetailsPokemon',
  data() {
    return {
      pokemon: null
    };
  },
  created() {
    const pokemonId = this.$route.params.id;
    this.fetchPokemonDetails(pokemonId);
  },
  methods: {
    async fetchPokemonDetails(id) {
      try {
        const response = await axios.get(`https://pokebuildapi.fr/api/v1/pokemon/${id}`);
        this.pokemon = response.data;
      } catch (error) {
        console.error("Erreur lors de la récupération des détails du Pokémon:", error);
      }
    }
  }
};
</script>

<style scoped>
.details-pokemon {
  text-align: center;
  padding: 20px;
}

.details-pokemon img {
  max-width: 100%;
  height: auto;
}
</style>
