<template>
  <div class="liste-types-pokemon">
    <h3>Types de Pokémon :</h3>
    <ul>
      <li v-for="(count, type) in typeCounts" :key="type">
        {{ type }} : {{ count }}
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'ListeTypesPokemon',
  props: {
    pokemons: Array
  },
  computed: {
    typeCounts() {
      const counts = {};
      this.pokemons.forEach(pokemon => {
        const type = pokemon.apiTypes[0].name;
        if (!counts[type]) {
          counts[type] = 0;
        }
        counts[type]++;
      });
      return counts;
    }
  }
};
</script>

<style></style>
