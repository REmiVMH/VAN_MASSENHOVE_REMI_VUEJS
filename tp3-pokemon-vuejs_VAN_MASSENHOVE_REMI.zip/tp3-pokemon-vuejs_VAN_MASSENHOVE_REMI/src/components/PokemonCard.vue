<template>
    <div class="pokemon-card" :style="{ backgroundColor: backgroundColor }" @click="goToDetails(pokemon.id)">
        <img :src="pokemon.image" :alt="pokemon.name" />
        <h2>{{ pokemon.name }}</h2>
        <div class="types">
            <div v-for="type in pokemon.apiTypes" :key="type.name" class="type">
                <img :src="type.image" :alt="type.name" />
                <span>{{ type.name }}</span>
            </div>
        </div>
        <p>Generation: {{ pokemon.apiGeneration }}</p>
    </div>
</template>
  
<script>
export default {
    name: 'PokemonCard',
    props: {
        pokemon: {
            type: Object,
            required: true
        }
    },
    computed: {
        backgroundColor() {
            const type = this.pokemon.apiTypes[0].name.toLowerCase();
            return this.typeToColor(type);
        }
    },
    methods: {
        goToDetails(id) {
            this.$router.push({ name: 'DetailsPokemon', params: { id: id } });
        },
        typeToColor(type) {
            const colors = {
                plante: '#78C850',  // Vert pour Plante
                feu: '#FF6F61',     // Rouge corail pour Feu
                eau: '#58ACFA',     // Bleu azur pour Eau
                électrik: '#FAD02E', // Jaune citron pour Électrique
                glace: '#00FFFF',   // Cyan pour Glace
                combat: '#D62D20',  // Rouge pour Combat
                poison: '#8A2BE2',  // Bleu violet pour Poison
                sol: '#F4A460',     // Brun clair pour Sol
                vol: '#87CEEB',     // Bleu ciel pour Vol
                psy: '#FF69B4',     // Rose vif pour Psy
                insecte: '#7FFF00', // Vert jaunâtre pour Insecte
                roche: '#DAA520',   // Jaune moutarde pour Roche  
                spectre: '#4B0082', // Indigo foncé pour Spectre
                dragon: '#663399',  // Violet foncé pour Dragon
                ténèbres: '#2E2E2E', // Gris foncé pour Ténèbres
                acier: '#B0C4DE',   // Bleu poudre pour Acier
                fée: '#FFB6C1',     // Rose clair pour Fée
                normal: '#D3D3D3'   // Gris clair pour Normal
            };
            return colors[type] || '#FFFFFF'; // Blanc par défaut si le type n'est pas trouvé
        }
    }
};
</script>
  
<style scoped>
img {
    max-width: 100%;
    height: auto;
}

.pokemon-card {
    margin: 5px;
    width: 30%;
    height: auto;
    border-radius: 10px;
    cursor: pointer;
    /* Ajout du curseur pointer au survol */
    transition: background-color 0.3s ease;
    /* Ajout de transition sur la couleur de fond */
}

.pokemon-card:hover {
    background-color: #ddd;
    /* Couleur de fond au survol */
}

.pokemon-card h2 {
    color: #FFF;
    font-size: 2em;
    text-transform: capitalize;
    text-align: center;
}

.pokemon-card p {
    color: #FFF;
    font-size: 1.5em;
    text-transform: capitalize;
    text-align: center;
}

.pokemon-card .types {
    display: flex;
    justify-content: center;
    color: #FFF;
    font-size: 1.5em;
}
</style>
  