<template>
  <div id="app">
    <input type="number" v-model="pokemonCount" placeholder="Nombre de Pokémon" /> <br> <br>
    <button @click="fetchPokemons">Charger</button>
    <ListeTypesPokemon :pokemons="pokemons" />
    <Pokedex :pokemons="pokemons" />
    <Footer />
  </div>
</template>

<script>
import axios from 'axios';
import Pokedex from './components/Pokedex.vue';
import Footer from './components/Footer.vue';
import ListeTypesPokemon from './components/ListeTypesPokemon.vue';
import DetailsPokemon from './components/DetailsPokemon.vue';

export default {
  name: 'App',
  components: {
    Pokedex,
    Footer,
    ListeTypesPokemon,
    DetailsPokemon
  },
  data() {
    return {
      pokemons: [],
      pokemonCount: 20
    };
  },
  methods: {
    async fetchPokemons() {
      try {
        const response = await axios.get(`https://pokebuildapi.fr/api/v1/pokemon/limit/${this.pokemonCount}`);
        this.pokemons = response.data;
      } catch (error) {
        console.error("Erreur lors de la récupération des données des Pokémon:", error);
      }
    }
  },
  created() {
    this.fetchPokemons();
  }
};
</script>

